# Role: AI Lead (B2)

> You own the concierge — the feature that earns the 25% AI score and most of the originality points. The judges will scrutinize whether AI is real and useful or just a chat widget. Make it real and useful.

---

## Your mission
Build a Claude-powered concierge that takes a student profile + free-form query + nearby places, and returns 3 grounded, personalized recommendations with reasoning. Plus a general chat endpoint. Both stream.

## What you own (deliverables)
- [ ] Anthropic client wrapper with retries and timeouts
- [ ] Prompt library: 3 well-engineered system prompts (concierge, checklist explainer, procedure summarizer)
- [ ] Endpoint: `POST /recommend` — main concierge feature
- [ ] Endpoint: `POST /chat` — general Q&A about Iași
- [ ] Streaming via Server-Sent Events (looks great in demo)
- [ ] Response caching for demo queries (zero risk of timeout on stage)
- [ ] Context injection: time of day, persona profile, nearby places
- [ ] Documented prompt design choices in `PROMPTS.md`

## Stack
- `anthropic` Python SDK
- FastAPI's `StreamingResponse` for SSE
- A simple in-memory dict cache (or SQLite if you want persistence)

```bash
pip install anthropic
```

API key in `.env` as `ANTHROPIC_API_KEY`. Add to Render secrets.

---

## Hour-by-hour

### H0–H2 — Setup
- Get an Anthropic API key. If team doesn't have one, that's the #1 thing to resolve in hour 0.
- Create `app/ai/` directory:
  ```
  app/ai/
    __init__.py
    client.py        # wraps Anthropic SDK
    prompts.py       # all system prompts
    cache.py         # response cache
    recommend.py     # core recommend logic
    chat.py          # core chat logic
  ```
- Write `client.py`: function `get_client()` returning a configured `Anthropic()`. Set default `max_tokens=1024`, sensible timeout.
- Smoke test: send "Hello" to Claude Haiku, print response.

### H2–H6 — Prompt v1 + /chat
- Write the concierge system prompt (see Appendix A). Keep it under 500 tokens — long prompts cost latency.
- Write `chat.py` with a `chat(persona, message, history)` function that returns a string.
- Wire `POST /chat` in a new `routers/chat.py`. Pydantic models for request/response. Non-streaming first.
- Test with cURL. Iterate on prompt: does it stay in character? Does it speak warmly? Does it refuse to invent places?

### H6–H10 — /recommend with grounding
- This is the headline feature. The prompt MUST instruct Claude to only recommend from places in the message — no hallucinated venues.
- Write `recommend.py`:
  ```python
  def recommend(persona_id: str, query: str, db) -> list[Recommendation]:
      profile = load_persona(db, persona_id)
      places = nearby_places(db, profile.location, radius_km=2)
      prompt = build_recommend_prompt(profile, query, places)
      response = client.messages.create(...)
      return parse_json_response(response)
  ```
- Force JSON output: use Claude's `response_format` or instruct in the prompt + parse with `json.loads` wrapped in try/except. If parse fails, retry once with a "your last response wasn't valid JSON, try again" message.
- Each recommendation must include `place_id` so the frontend can pin it on the map.

### H10–H14 — Streaming + context awareness
- Convert `/chat` and `/recommend` to streaming SSE. Frontend will display words appearing — looks 10x more impressive than a single block.
- Add context injection: current time of day, day of week, weather (optional — use `wttr.in` free API if you want).
- Test prompt variants. For each demo persona, run 5 different queries and check quality. Tune.

### H14–H18 — Caching + safety net
- Build `cache.py`: hash `(persona_id, query)` → response. Store. On cache hit, replay the stream from disk word-by-word with the same timing. Looks identical to live.
- Pre-warm the cache with the EXACT demo queries. This is your insurance policy if Claude is slow or down during pitch.
- Add a server-side toggle `USE_CACHE_ONLY` env var. If something goes wrong on demo day, flip it on.
- Document everything in `PROMPTS.md`: which prompt, why, what alternatives you tried, what failed.

### H18–H22 — Demo polish
- Run the demo prompt 10 times. Watch the responses. Pick the 2-3 best, lock them as the cached defaults.
- Coordinate with F: chat panel should show streaming dots while waiting, then stream the response. Add a subtle "powered by Claude" footer (judges notice).
- Bonus: implement a "retry" or "regenerate" button for AI responses — the brief explicitly calls this out as bonus points (Technical Execution, AI section).

### H22–H24 — Buffer
- Final cache warm-up.
- Verify API key is valid on Render (not just local).
- Document fallback procedure in case Claude returns errors mid-demo.

---

## Dependencies (who you need, when)
| When | From | What |
|------|------|------|
| H0 | All | Anthropic API key |
| H6 | D | Real personas seeded in DB so prompts get realistic profiles |
| H6 | B1 | DB session helper to read places |
| H8 | D | Final list of POIs in DB — quality of recommendations depends on quality of POI descriptions |
| H10 | F | Agreement on streaming format (SSE) |

## What you need to give others
- Sample JSON responses for F to render against.
- `PROMPTS.md` so P can reference it in pitch ("we use structured prompting with grounding to avoid hallucination").

---

## Common pitfalls — avoid these
- **Don't let Claude invent places.** Every recommendation must reference a `place_id` that exists in the DB. Validate this server-side; reject responses that don't.
- **Don't ship a 2000-token system prompt.** Latency kills demo magic. Aim for <500 tokens.
- **Don't skip caching.** Live API calls during a 90-second demo are a coin flip. Cache the demo path.
- **Don't put the API key in code.** `.env` locally, Render secrets in prod.
- **Don't forget JSON parsing failures.** Claude occasionally returns text around JSON. Use a regex extractor: `re.search(r'\[.*\]', text, re.DOTALL)`.
- **Don't claim "trained model" in the pitch.** Be honest: prompt-engineered RAG over our curated database. That's still strong.

## Done checklist (before demo freeze at H18)
- [ ] `/chat` and `/recommend` work on live URL
- [ ] Both stream cleanly
- [ ] Demo queries cached and tested
- [ ] No JSON parse failures across 20 test runs
- [ ] Prompts documented in `PROMPTS.md`
- [ ] Retry/regenerate button exists (bonus)

---

## Appendix A — Concierge system prompt (starter)

```
You are Student Compass, a warm, practical, locally-rooted guide for students new to Iași, Romania.

Your job: take the student's profile and what they're looking for, then recommend EXACTLY 3 places from the provided list.

Rules:
1. ONLY recommend places from the JSON list provided in the user message. Never invent a venue.
2. Tailor to the student's profile: budget-conscious, language barriers, status (Erasmus / first-year / etc.), time available.
3. Each recommendation must include: name, place_id (copied from the list), and ONE sentence of reasoning that references something concrete about the student.
4. Speak warmly, like a friend who knows the city, not like a brochure.
5. If none of the provided places fit the request, say so plainly and suggest the closest alternative.

Output format (strict JSON, no prose around it):
[
  {"place_id": "...", "name": "...", "reason": "..."},
  {"place_id": "...", "name": "...", "reason": "..."},
  {"place_id": "...", "name": "...", "reason": "..."}
]

Student profile:
{profile_json}

Current context:
- Time: {time_of_day}
- Day: {day_of_week}
- Available time: {time_available}
```

## Appendix B — Quick prompt-tuning tips
- **Lower temperature for /recommend** (0.3) so output is consistent.
- **Higher temperature for /chat** (0.7) so conversation feels alive.
- **Few-shot example** in the system prompt of one good recommendation helps a lot for free.
- **Specify what bad outputs look like** ("Do not say 'I recommend visiting...' — just return the JSON").
