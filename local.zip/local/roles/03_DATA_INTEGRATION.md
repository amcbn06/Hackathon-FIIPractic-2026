# Role: Data + Integration (D)

> You are the soul of the demo. The app's intelligence is only as good as the data you put in it. If your procedures, personas, and POIs feel authentic and locally true, the judges will notice. If they feel generic, the demo fails.

---

## Your mission
Curate the highest-quality demo content possible: 5 sharp personas, 30+ Iași POIs from OSM, 5 hand-written bureaucracy procedures, 20 unwritten-rules tips, and the Romanian-language phrases that make it feel real.

## What you own (deliverables)
- [ ] OSM Overpass query for Iași, scripted to run on backend startup
- [ ] `seed.py` module with `load_all(session)` that idempotently seeds everything
- [ ] 5 personas covering different demo scenarios (Erasmus EU, Erasmus non-EU, Romanian first-year, internship, summer school)
- [ ] 30+ real Iași POIs (libraries, study cafés, theaters, museums, gyms, parks, hospitals, banks)
- [ ] 5 complete bureaucracy procedures (residence permit, NIN/CNP, BCR/BT bank account, RATP transport card, family doctor registration)
- [ ] 20 "unwritten rules" tips (where to find cheap food, which neighborhoods to avoid late, how to use Lifowl/Tazz, etc.)
- [ ] Romanian language phrases embedded in each procedure ("La ce ghișeu trebuie să merg?")
- [ ] One timely event seeded (real upcoming Filarmonica Iași concert or UAIC event)
- [ ] Integration testing — verify everything flows end-to-end

---

## Hour-by-hour

### H0–H2 — Research + scope
- Pull the master plan, read it twice.
- Open Google Maps / Iași in browser. Bookmark:
  - Inspectoratul General pentru Imigrări — Iași
  - BCR or Banca Transilvania near Copou
  - CTP Iași (transport card office)
  - A family doctor / clinic near campus
  - 5 student-popular cafés near UAIC (Meron, Caffeine, etc.)
  - 3 libraries (BCU Iași, Casa Cărții, BMM)
  - Filarmonica Iași — check current concert schedule
- Decide the 5 personas. Suggested:
  1. **Marco**, 22, Erasmus, Italian, UAIC FII — non-Romanian, EU, needs full bureaucracy lite.
  2. **Aisha**, 24, Erasmus, Nigerian, UMF — non-EU, needs full visa procedure.
  3. **Ana**, 19, Romanian first-year, from Botoșani, UAIC Letters — no visa, focus on settling.
  4. **Tomáš**, 26, Czech, internship at Continental — professional, short stay.
  5. **Yuki**, 21, Japanese, summer school, UAIC — short stay, tourist + light bureaucracy.

### H2–H6 — OSM ingestion + seed scaffold
- Write `app/seed/osm_fetch.py`:
  ```python
  import requests, json
  
  IASI_BBOX = (47.10, 27.50, 47.22, 27.68)  # south, west, north, east

  QUERY = """
  [out:json][timeout:25];
  (
    node["amenity"~"library|cafe|theatre|university|bank|pharmacy|hospital|police"](%s,%s,%s,%s);
    node["leisure"~"fitness_centre|park|sports_centre"](%s,%s,%s,%s);
    node["tourism"~"museum|gallery|attraction"](%s,%s,%s,%s);
  );
  out body;
  """ % (IASI_BBOX * 3)
  
  def fetch():
      r = requests.post("https://overpass-api.de/api/interpreter", data=QUERY)
      return r.json()["elements"]
  ```
- Cache the result to `data/iasi_osm.json` — DO NOT hit Overpass during demo or on every server start.
- Write `seed.py` with `load_all(session)`:
  - Loads personas (hardcoded list in `seed/personas.py`)
  - Loads procedures (in `seed/procedures.py`)
  - Loads OSM data from cache file
  - Filters POIs to "demo-worthy" (well-named, has tags, in radius of Copou)
  - Augments OSM data with our own descriptions/tips

### H6–H10 — Write procedures (this is the heart of your work)
- Each procedure file should be detailed enough to feel real. Example structure:

  ```python
  RESIDENCE_PERMIT = Procedure(
      slug="residence-permit-eu",
      title="Get your residence registration (EU students)",
      applies_to=["erasmus_eu", "internship_eu"],
      urgency_rank=1,
      address="Inspectoratul General pentru Imigrări Iași, Bd. Carol I nr. 18",
      hours="Mon-Fri 8:30–14:00",
      time_estimate="2 visits, ~2 weeks for the card",
      cost="120 RON tax",
      documents=[
          "Passport + 2 copies",
          "University enrollment letter (from UAIC)",
          "Proof of accommodation (rental contract or dorm letter)",
          "Health insurance (EHIC for EU)",
          "Bank statement showing min 580 RON/month",
      ],
      steps=[
          "Take the bus 28 or 47 to Copou and walk 5 min, or tram 1 to Carol I.",
          "Take a ticket (the office uses queue numbers — arrive before 9:00).",
          "Submit the document folder at ghișeul 3 or 4.",
          "Pay the 120 RON tax at the cashier downstairs (cash only, exact change preferred).",
          "Return with the receipt. They give you a temporary certificate.",
          "Card arrives by mail in 10–14 days.",
      ],
      phrases_ro=[
          ("La ce ghișeu trebuie să merg?", "Which counter should I go to?"),
          ("Mai aveți nevoie de alte documente?", "Do you need any other documents?"),
          ("Când îmi va sosi cardul?", "When will my card arrive?"),
      ],
      tips=[
          "Bring your own pen.",
          "The cashier closes at 13:30, not 14:00.",
          "Don't lose the receipt — you need it to collect the card.",
      ],
  )
  ```

- Write all 5 procedures with this level of detail. Yes, it's a lot of typing. This is what wins.
- Cross-check addresses on Google Maps. If the address is wrong, the demo dies.

### H10–H14 — Tips, phrases, and the timely event
- Write 20 "unwritten rules" tips. Examples:
  - "Tazz delivers 24/7 but Bolt Food has better restaurants. Glovo is dead in Iași."
  - "Bus 28 connects Copou to the train station — if you live in Tudor Vladimirescu, this is your line."
  - "The Wednesday morning farmer's market behind Hala Centrală is half the price of Kaufland."
  - "Don't pay 'cash directly' for any apartment — every legit landlord uses bank transfer."
  - "Casa Filarmonicii has free organ recitals on Sunday afternoons in winter."
- These are gold for the pitch and for filling chat responses.
- Look up ONE real upcoming Filarmonica concert (or theater performance, or UAIC event). Seed it as a special "event" type place. The judges will check and see it's real — huge credibility.

### H14–H18 — Integration testing
- Run the full system. Hit every endpoint with every persona.
- Verify: Marco's checklist has residence permit. Aisha's checklist has visa renewal. Ana's checklist has neither.
- Verify: concierge recommends places that actually exist near Copou and not in some random other city.
- Manually try 10 queries per persona in the chat. Flag bad outputs back to B2 for prompt tuning.
- Sit next to F and click through every screen. If a place doesn't have a description, write one.

### H18–H22 — Demo content lock
- Pick the EXACT examples that will appear in the 90s demo. Make sure they look pixel-perfect.
- Verify: the procedure Marco clicks in demo is fully filled in, formatted well, no lorem ipsum.
- Verify: the 3 concierge recommendations for "I'm tired, 3 hours, cultural, cheap" return GREAT picks. If they don't, edit the prompt with B2 or curate the candidate places.

### H22–H24 — Buffer
- Final spell-check on procedures and tips. Romanian phrases especially.
- If you know a native Romanian speaker outside the team, get them to skim the procedures for 5 minutes.

---

## Dependencies (who you need, when)
| When | From | What |
|------|------|------|
| H2 | B1 | Empty SQLAlchemy models with field signatures so you can write seeds |
| H6 | B1 | DB session helper to call `load_all(session)` |
| H10 | F | They'll start asking for example queries and screenshots — feed them good ones |

## What you need to give others
- `app/seed/load_all.py` callable by B1 at startup.
- A list of "demo-perfect examples" to F by H16: which persona to pick, which procedure to click, which chat query to type. F builds the demo flow around this.
- Sample chat queries + expected responses to P for the pitch deck.

---

## Common pitfalls — avoid these
- **Don't auto-translate Romanian phrases.** Get them right. A wrong phrase is worse than no phrase.
- **Don't pull live OSM during demo.** Cache to JSON, load from cache. Overpass is rate-limited and slow.
- **Don't generic-up the procedures.** "Bring your documents" is bad. "Bring your EHIC card and a copy on A4 paper" is good.
- **Don't seed 200 POIs.** 30 great ones beat 200 noisy ones. The concierge will pick from this list — quality > quantity.
- **Don't forget edge cases.** Empty checklist for a persona? Loading state? At least 1 procedure must exist for every persona.

## Done checklist (before demo freeze at H18)
- [ ] OSM data cached, loaded into DB
- [ ] All 5 personas in DB with distinct profiles
- [ ] All 5 procedures fully written with addresses, steps, phrases, tips
- [ ] 20+ tips seeded
- [ ] 1 real timely event seeded
- [ ] Demo-perfect examples shared with F
- [ ] Native speaker eyeballed Romanian phrases
- [ ] Every persona produces a different, sensible checklist
