# Role: Backend Lead (B1)

> You own the FastAPI service, the database, and deployment. You are the spine of the app. If your endpoints are flaky, everything else fails.

---

## Your mission
Ship a clean REST API that serves places, checklists, and procedures from a real SQLite database, deployed to a public URL by Hour 6 and stable through demo time.

## What you own (deliverables)
- [ ] FastAPI project scaffold (clean structure: `routers/`, `models/`, `db/`, `schemas/`)
- [ ] SQLAlchemy models for `Place`, `Procedure`, `Persona`, `Tip`
- [ ] SQLite database with Alembic-free init script
- [ ] Endpoints: `GET /places`, `GET /checklist`, `GET /procedure/{slug}`, `GET /personas`, `GET /healthz`
- [ ] Auto-generated Swagger docs at `/docs`
- [ ] Production deploy on Render or Railway with auto-deploy from `main`
- [ ] `.env.example` and clean README section for "how to run"
- [ ] Error handling: no uncaught 500s in front of judges

## Stack
- Python 3.11, FastAPI, Uvicorn, SQLAlchemy, Pydantic v2, python-dotenv
- SQLite (file-based, no server)
- Deploy: Render (free tier is fine for demo)

```bash
pip install fastapi uvicorn sqlalchemy pydantic python-dotenv
```

---

## Hour-by-hour

### H0–H2 — Kickoff
- Sit with full team for scope alignment. Speak up if scope feels too big.
- Create the GitHub repo. Set up branch protection on `main`.
- Project skeleton:
  ```
  app/
    main.py
    db/
      __init__.py
      session.py
      models.py
    routers/
      places.py
      checklist.py
      procedure.py
      personas.py
    schemas/
      place.py
      checklist.py
    seed/
      __init__.py  (D fills this)
    config.py
  requirements.txt
  .env.example
  README.md
  ```
- `main.py` boots FastAPI, mounts routers, runs DB init on startup.
- Push to `main`. Verify CI/CD if you set it up; if not, that's fine.

### H2–H6 — Database + first endpoint + deploy
- Define SQLAlchemy models exactly as in the master plan (Section 4).
- Write `db/session.py` with a sync engine + session factory.
- Write a `db/init.py` that creates tables and calls `seed.load_all(session)` (D will provide `load_all`).
- Build `GET /places?lat&lon&radius&category` — use simple Haversine in Python, no PostGIS needed.
- **Deploy "hello world" to Render NOW.** Don't wait. Get the URL live before you build features. This is hour 5 max.
- Share the live URL in the team channel. F will integrate against it.

### H6–H10 — Core endpoints
- `GET /personas` — returns all personas from seed.
- `GET /checklist?persona_id=...` — joins persona → relevant procedures, returns ordered list. Order by an `urgency_rank` field on `Procedure`.
- `GET /procedure/{slug}` — full step-by-step, address, Romanian phrases. Returns 404 if not found.
- Make sure F can hit your live URL with CORS allowed. Add `CORSMiddleware(allow_origins=["*"])` for the hackathon.

### H10–H14 — Hardening
- Add `urgency_rank` logic: filter procedures by persona's `applies_to` (e.g., visa items only for non-EU).
- Logging middleware: log every request method, path, status, duration. Helps debug.
- Custom exception handlers so any error returns clean JSON, never a stack trace.
- Coordinate with B2: they need to read `places` from your DB inside their `/recommend` endpoint. Share the SQLAlchemy session helper.

### H14–H18 — Bug bash + polish
- Walk through the demo script with F. Hit every endpoint your demo path touches. Fix any latency spikes (>500ms is unacceptable; cache where needed).
- `GET /healthz` returns `{"ok": true}`. Configure Render health check to ping it.
- Add `/docs` and `/redoc` — check they look professional. Judges may click them.
- Tag a release: `git tag v1.0-demo && git push --tags`.

### H18–H22 — Demo support
- Sit next to F during demo rehearsal. Watch network tab. If anything errors, fix it.
- Pre-warm the deploy 10 minutes before pitch (Render free tier sleeps).
- Backup: have the app running locally with `uvicorn --port 8000` as a fallback if Render dies.

### H22–H24 — Buffer
- README: how to run locally, deployed URL, architecture diagram (use Mermaid in Markdown).
- Push final, tag, sleep if you can.

---

## Dependencies (who you need, when)
| When | From | What |
|------|------|------|
| H4 | D | Seed `load_all()` function importable from `app.seed` |
| H4 | D | Initial seed data committed (at least personas + procedures) |
| H6 | F | They start integrating against your `/places` |
| H10 | B2 | Agree on shape of `places` passed to `/recommend` |
| Always | P | Nothing technical, but support them with screenshots for slides |

## What you need to give others
- The deployed base URL (e.g., `https://student-compass.onrender.com`) by H5.
- API schema (Swagger link) shared in team channel.
- Test cURL commands in `README.md` so F and B2 can poke the API without asking you.

---

## Common pitfalls — avoid these
- **Don't add auth.** No login, no JWT, nothing. Personas are just IDs you pass as query params.
- **Don't over-architect.** No microservices, no async DB driver, no Alembic migrations. SQLite + sync SQLAlchemy is correct.
- **Don't skip deployment to H10.** If you wait, you'll hit Render quirks at H20 with no time to debug.
- **Don't forget CORS.** Streamlit on a different origin will fail silently if CORS is off.
- **Don't return raw SQLAlchemy objects.** Use Pydantic schemas — explicit response models.

## Done checklist (before demo freeze at H18)
- [ ] All 5 endpoints work on the live URL
- [ ] No 500s when hit with the demo persona
- [ ] Swagger docs render correctly at `/docs`
- [ ] Health check returns 200
- [ ] README has run instructions + deployed URL
- [ ] Logs visible in Render dashboard
- [ ] Demo script's API path tested end-to-end at least 3 times
