# Role: Frontend (F)

> You build the face of the app. With Streamlit, you can ship a working UI fast — but "looks like default Streamlit" will hurt the score. Your job is making it feel intentional, not templated.

---

## Your mission
A working Streamlit app with: persona picker, map of Iași with categorized POIs, a checklist view, a procedure detail view, and a chat sidebar with streaming responses. By H18 it must look styled, not stock.

## What you own (deliverables)
- [ ] Streamlit app with multi-page or single-page navigation
- [ ] Persona selector in sidebar
- [ ] Folium map embedded via `streamlit-folium`, with category filter checkboxes
- [ ] Checklist view (cards or list with urgency badges)
- [ ] Procedure detail page (address, steps, phrases, tips)
- [ ] Chat panel with streaming responses
- [ ] Consistent color palette + typography
- [ ] Mobile-responsive enough for a phone screenshot
- [ ] Loading states and empty states
- [ ] Hide the "Made with Streamlit" footer
- [ ] App icon + tab title

## Stack
```bash
pip install streamlit streamlit-folium folium requests
```
- `streamlit` for the framework
- `folium` + `streamlit-folium` for the map
- `requests` to hit the FastAPI backend

---

## Hour-by-hour

### H0–H2 — Setup
- Install Streamlit, get hello-world running with `streamlit run app.py`.
- Choose a color palette early. Suggested: navy (#1B3A57) primary, warm yellow (#F5C242) accent, off-white (#FAF9F6) background, slate grey (#5C5C5C) text. Use [coolors.co](https://coolors.co) to lock it in.
- Skeleton:
  ```
  frontend/
    app.py            # entry point
    pages/            # if using multi-page
      1_Map.py
      2_Checklist.py
      3_Chat.py
    components/
      persona_picker.py
      map_view.py
      checklist_card.py
      chat_panel.py
    utils/
      api.py          # all backend calls
      styling.py      # custom CSS
    .streamlit/
      config.toml     # theme
  ```
- Set up `.streamlit/config.toml` with theme colors. This is the lowest-effort way to look non-default.

### H2–H6 — Skeleton + map
- Sidebar: persona picker (`st.selectbox`) hitting `GET /personas`. Store selection in `st.session_state`.
- Main area: folium map centered on Copou (47.1900, 27.5586), zoom 14.
- Add a placeholder marker so you can see it works.
- Hit `GET /places?lat=47.19&lon=27.56&radius=2` and render markers. Use different icons per category.
- Hide Streamlit chrome:
  ```python
  st.markdown("""
  <style>
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
  </style>
  """, unsafe_allow_html=True)
  ```
- Page title via `st.set_page_config(page_title="Student Compass", page_icon="🧭", layout="wide")`.

### H6–H10 — Checklist + procedure detail
- Add navigation: tabs or radio buttons for "Map / Checklist / Chat" (or use multi-page).
- Checklist view: hit `GET /checklist?persona_id=...`, render each item as a card with title, urgency badge, "View details" button.
- Procedure detail: clicking a checklist item navigates to (or opens an `st.expander`) showing address, hours, documents (bulleted), steps (numbered), Romanian phrases (two-column table), tips.
- Make procedure pages SHAREABLE-looking — they're the highest-density "wow" content in the demo.

### H10–H14 — Chat panel + map filters
- Chat panel in a column or sidebar:
  - `st.chat_message` and `st.chat_input` for the conversational UI.
  - On submit, POST to `/chat` and stream the response using `st.write_stream`.
  - Maintain history in `st.session_state["chat_history"]`.
- For the concierge: dedicated button "Ask the compass" that opens a richer flow with 3 result cards + map highlights.
- Map filters: `st.checkbox` for each category (Study, Food, Culture, Sport, Bureaucracy, Events). Re-render markers when toggled.
- Color-code markers by category. Use Folium's `Icon(color=..., icon=...)`.

### H14–H18 — Polish (this hour bucket is where you earn the score)
- Custom CSS: card shadows, rounded corners, consistent button styles. Inject via `st.markdown(..., unsafe_allow_html=True)`.
- Empty states: when checklist is empty, show a friendly message + illustration (use an emoji or simple SVG).
- Loading states: every API call wrapped in `with st.spinner("Finding things near you...")`.
- Error states: if backend is down, show "Reconnecting..." not a red traceback.
- Hero header: app name + tagline at the top of the page in a styled banner.
- Pre-load: cache `GET /personas` and `GET /places` with `@st.cache_data(ttl=300)`.

### H18–H22 — Demo rehearsal
- Walk the demo script step by step. Time it. Aim for 90s flat.
- If a transition feels janky, fix it. Demo is about flow, not features.
- Take 4–5 screenshots for the slide deck (give to P).
- Test on a different laptop and a phone. Fix anything that breaks.

### H22–H24 — Buffer
- Final styling pass.
- Verify the deployed Streamlit (on Streamlit Cloud or Render) matches local.

---

## Dependencies (who you need, when)
| When | From | What |
|------|------|------|
| H4 | B1 | Live deployed FastAPI URL with `/places` returning data |
| H6 | B1 | `/personas` and `/checklist` working |
| H6 | D | Real seed data showing in API responses |
| H10 | B2 | Streaming `/chat` and `/recommend` working |
| H16 | D | "Demo-perfect examples" — exact persona + clicks + queries for the 90s demo |

## What you need to give others
- 4–5 polished screenshots to P by H16 for the slide deck.
- Final styled URL to share at demo time.

---

## Common pitfalls — avoid these
- **Don't use raw `st.button` for everything.** It looks generic. Use cards, columns, and custom CSS for primary CTAs.
- **Don't hardcode persona data in the frontend.** Always hit the API — judges will see hardcoded data and dock you.
- **Don't ignore mobile.** Use `layout="wide"` but test on a narrow window. Streamlit reflows OK if columns are sized right.
- **Don't put error tracebacks on screen.** Wrap every `requests.get` in try/except and show a friendly fallback.
- **Don't forget the icon and page title.** Free credibility.
- **Don't ship without hiding the Streamlit footer.** The "Made with Streamlit" badge screams "intern project."

## Done checklist (before demo freeze at H18)
- [ ] Persona switching changes checklist + recommendations live
- [ ] Map shows categorized markers with filter checkboxes
- [ ] Chat streams responses word-by-word
- [ ] Procedure pages look readable and finished
- [ ] No default Streamlit chrome visible
- [ ] App works on the deployed URL, not just local
- [ ] Demo script runs end-to-end in under 100 seconds
- [ ] 4–5 screenshots delivered to P

---

## Appendix A — Custom theme starter

`.streamlit/config.toml`:
```toml
[theme]
primaryColor = "#F5C242"
backgroundColor = "#FAF9F6"
secondaryBackgroundColor = "#FFFFFF"
textColor = "#1B3A57"
font = "sans serif"
```

## Appendix B — Folium marker color map
```python
CATEGORY_STYLE = {
    "library":         {"color": "blue",   "icon": "book"},
    "cafe":            {"color": "orange", "icon": "coffee"},
    "theatre":         {"color": "purple", "icon": "music"},
    "museum":          {"color": "purple", "icon": "university"},
    "fitness_centre":  {"color": "green",  "icon": "heartbeat"},
    "park":            {"color": "green",  "icon": "tree"},
    "bank":            {"color": "gray",   "icon": "credit-card"},
    "pharmacy":        {"color": "red",    "icon": "plus-square"},
    "police":          {"color": "darkblue","icon": "shield"},
}
```
