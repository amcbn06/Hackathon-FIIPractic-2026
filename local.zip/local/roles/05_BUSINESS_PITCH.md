# Role: Business + Pitch (P)

> You are the most important role on this team. Business Viability + Pitch = **70% of the total score**. Your work is what turns a working demo into a winning project. Treat this like a full-time job for 24 hours.

---

## Your mission
Produce a research-backed business case, a polished slide deck, and a rehearsed pitch. By Hour 24 your team should walk to the stage knowing exactly what to say and what to click.

## What you own (deliverables)
- [ ] `BUSINESS.md` — full business viability analysis (market, competitors, model, financials, SWOT, roadmap)
- [ ] Slide deck (12 slides max) — clean, low-text, visual
- [ ] Demo script (the 90-second flow) — written and rehearsed
- [ ] Q&A prep doc — answers to 8–10 likely judge questions
- [ ] Final pitch delivery + live demo run (with one dev driving)
- [ ] Polished `README.md` for the GitHub repo (front-page impression)

---

## Hour-by-hour

### H0–H2 — Frame the story
- Read all 5 hackathon briefs again. Highlight scoring language. The judges literally tell you what they want.
- Write a one-sentence answer to each:
  1. **What's the problem?** (with a number)
  2. **Who has it?** (specific segment)
  3. **What's our solution?** (in plain words)
  4. **Why now?** (timing argument)
  5. **Why us?** (defensibility)
- Draft a hook story. Real, specific, human. Example: "Maria arrived in Iași from Bologna last September. By day 14 she still hadn't registered her residence. By day 21 she nearly went home." Use a real-sounding name (not "John Doe").

### H2–H6 — Market research
- Build `BUSINESS.md`. Sections:
  1. Problem
  2. Target market (segmented)
  3. Competitive landscape
  4. USP
  5. Revenue model
  6. Cost structure
  7. Unit economics
  8. Break-even analysis
  9. Growth strategy + roadmap
  10. SWOT
- Numbers to find (cite sources where you can):
  - Erasmus students arriving in Romania per year (search "Erasmus+ statistics Romania", check ec.europa.eu)
  - UAIC international students (UAIC publishes annual reports)
  - Total Romanian university students (Eurostat or INS)
  - Student churn / dropout rate, especially international
  - Cost of acquiring a student via university partnership (estimate from edtech comparables)
- Competitors to research and write 2-3 lines each:
  - Erasmus+ official app
  - HousingAnywhere
  - Welcome.eu
  - Google Maps / Yelp
  - UniBuddy
  - University intranet portals
  - WhatsApp/Telegram student groups (informal competitor — this is real)
- Don't make up numbers. If you must estimate, say "estimated" and give the assumption.

### H6–H10 — Business model + financials
- Revenue streams (be concrete):
  - **B2C Freemium.** Free: checklist + map + 5 AI queries/day. Premium €2.99/mo: unlimited AI, offline, saved itineraries.
  - **B2B Institutional.** €2–5 per student/year licensed to universities. Negotiated annual contract. Includes white-label.
  - **Local partnerships.** Sponsored listings, labeled clearly. €50–200/month per business in Iași.
- Costs:
  - Anthropic API: estimate Claude Haiku at ~€0.001 per query, ~50 queries/active user/month = €0.05/user/mo
  - Hosting: Render Pro tier ~€20/mo for a small app, scales to ~€100/mo
  - Founder time: 2 FTE x €2,000/mo (Iași salaries) = €4,000/mo
  - Misc (domain, monitoring, design): ~€100/mo
- Break-even: figure out what % of users go premium (industry standard 2–5%). Pick 3%. At 10,000 free users → 300 premium → €897/mo revenue. Then add B2B: 1 university contract @ 5,000 students × €3 = €15,000/year. Suddenly profitable.
- 3-year forecast: 1,000 users Year 1, 25,000 Year 2, 100,000 Year 3 (with Romania-wide expansion).

### H10–H14 — Slide deck draft v1
- Use Google Slides, Pitch.com, or PowerPoint. NOT Canva — it's slow and crashes.
- 12 slides max:
  1. Title (logo, team, tagline)
  2. Hook story (1 image, 3 lines of text)
  3. Problem (with the big number)
  4. Solution (1 product screenshot, 3 pillars)
  5. **DEMO BREAK** (placeholder slide, "Live Demo")
  6. Tech architecture (diagram from master plan)
  7. AI deep-dive (prompt structure, why it doesn't hallucinate)
  8. Market (TAM/SAM/SOM funnel)
  9. Competition (2x2 grid or table)
  10. Business model (revenue streams + unit economics one-liner)
  11. Roadmap (4 quarters)
  12. Close (vision + ask)
- Visual rules: max 8 words per slide title, no paragraph text, big numbers, 1 visual per slide.
- Font: pick ONE sans-serif (Inter, Manrope, or Source Sans). 32pt minimum for body.
- Color palette: match the app's palette so everything feels unified.

### H14–H18 — Demo script + practice
- Get F to walk you through the working app. Write the demo script EXACTLY as it should be spoken:
  - Every sentence the talker says
  - Every click the screen-driver does
  - Timing markers ([0:00], [0:10], [0:30]...)
- Time it. Goal: 90 seconds. If you're over, cut, don't speed up.
- Decide who talks and who drives. The talker doesn't touch the keyboard. The driver doesn't talk.
- Practice the full 7-minute pitch with team. Time each section. Iterate slides if any section runs long.

### H18–H22 — Q&A prep + final polish
- Anticipate 10 questions and write 2–3 sentence answers. See Appendix A.
- Run a mock Q&A: have 1–2 teammates throw hard questions, you answer cold. Take notes on what you stumbled on.
- Final slide polish: visual consistency, alignment, spacing. Print to PDF and look at it small — does it still read?
- Write the README.md for the GitHub repo:
  - One-line description
  - Screenshot
  - Live demo URL
  - Architecture diagram
  - How to run locally
  - Team members
  - Tech stack
  - Roadmap teaser

### H22–H24 — Buffer + rehearsal
- One more full pitch + demo run-through.
- Hydrate. Eat. Sleep an hour if you can.
- Have a printed copy of the slide deck (in case projector issues).
- Confirm: laptop charged, presenter clicker ready, backup demo video on USB.

---

## Dependencies (who you need, when)
| When | From | What |
|------|------|------|
| H2 | All | Team agreement on USP wording |
| H8 | B1 | Live URL to put on slides |
| H12 | F | App screenshots for slides |
| H14 | B2 | "How does the AI work?" one-paragraph explanation |
| H14 | D | Real stats: "we seeded N places, M procedures" for credibility slide |
| H16 | F | Final demo flow confirmed for the script |

## What you need to give others
- The deck for everyone to review by H18.
- The demo script to F and the screen-driver, memorized by H20.
- Confidence and morale. You're the team's emotional anchor.

---

## Common pitfalls — avoid these
- **Don't write code.** If you have spare cycles, polish slides or rehearse, don't help debug.
- **Don't put bullet lists on slides.** One image, one line, one number. The deck supports YOU; you're the speaker.
- **Don't make up numbers.** Judges with industry backgrounds will sniff fake stats instantly. Estimate openly: "We estimate ~30K Erasmus students based on Erasmus+ 2023 reports."
- **Don't pitch features in the pitch.** Pitch the *problem* and let the demo show features.
- **Don't go over time.** 7 minutes hard. Practice with a timer. Get a teammate to flash a "1 min left" sign.
- **Don't apologize for "this is a hackathon project".** Pitch it like it's a real company.

## Done checklist (before pitch)
- [ ] `BUSINESS.md` complete with all 10 sections
- [ ] 12-slide deck saved as PDF + .pptx + Google Slides link
- [ ] Demo script written, timed, memorized
- [ ] Q&A doc with 10 answers
- [ ] README polished on GitHub
- [ ] Full pitch rehearsed at least 3 times end-to-end
- [ ] Backup demo video recorded (60s screen capture)
- [ ] Printed deck as backup

---

## Appendix A — Likely judge questions + draft answers

1. **How is this different from Google Maps?**
   > Maps gives you a pin. We give you a plan. The compass knows you're an Erasmus student from Italy, that you arrived two weeks ago, that you haven't done your residence registration yet. It prioritizes what matters to *you* this week, not what's geographically nearest.

2. **Why would a university pay for this?**
   > International student retention is a tracked metric for every university. Drop-outs in the first semester are expensive — lost tuition, lost rankings, reputational damage. A €5/student tool that demonstrably reduces week-one churn is a no-brainer for any international office.

3. **How do you handle wrong AI answers about bureaucracy?**
   > The AI doesn't generate bureaucracy answers — it summarizes our human-curated database. Procedures are structured data: address, hours, documents, steps. The model can't hallucinate them, only restate them. That's why our approach is closer to RAG than chatbot.

4. **What stops a competitor from copying you?**
   > Our defensibility isn't code — it's data. Hand-verified procedures and curated unwritten rules per city take months to seed and update. We get there first in Romanian cities and partner with universities for distribution.

5. **What's your moat at scale?**
   > Network effects through crowdsourcing: every student who uses the app and submits a tip improves it. Combined with university partnerships, switching cost becomes high.

6. **Why didn't you build an actual mobile app?**
   > For a 24-hour hackathon, a responsive web app was the right tradeoff. We architected the backend so a React Native or Flutter client is the natural next step — that's quarter one post-launch.

7. **How big is your TAM realistically?**
   > Roughly 1.3 million Erasmus students per year, plus ~3 million students relocating within their own country in the EU annually. We don't need 1% — we need to be the default in a handful of Romanian university cities first.

8. **How do you acquire users?**
   > Two channels. Bottom-up: TikTok and Reddit through Erasmus communities. Top-down: partnering with university international offices to make us the recommended companion at orientation.

9. **Are you worried about Google adding this to Maps?**
   > Google is unlikely to verify Romanian residence permit procedures at counter 3 of the Iași immigration office. That hyperlocal depth is exactly where we win.

10. **What would you do with funding?**
   > Hire two more engineers and a community manager. Expand to four more Romanian cities in six months. Build the iOS app. Pilot with one university for retention data we can use to close more B2B deals.

---

## Appendix B — Pitch one-liner cheat sheet

Memorize these. If you're nervous on stage, fall back to them.

- **The 1-sentence pitch:** "Student Compass is an AI arrival companion that turns the first month in a new city from chaos into a personalized week-one plan."
- **The differentiator:** "Maps tells you where things are. We tell you what to do next."
- **The market:** "Thirty thousand Erasmus students arrive in Romania every year, plus half a million Romanian students moving for university. Every single one of them is currently winging it."
- **The vision:** "One student. One city. One compass."
