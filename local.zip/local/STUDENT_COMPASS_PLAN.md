# Student Compass — FII Practic Hackathon Plan

> 24 hours. 5 people. Iași. Hybrid AI Concierge + Map.
> Built to win on **Business Viability & Originality (40%)** while shipping a working demo (Technical 30%) and a sharp pitch (Pitch 30%).

---

## 1. Executive Summary

**What we're building:** *Student Compass* — an AI-powered arrival companion for students new to Iași. It combines a personalized bureaucracy/arrival checklist, a discovery map of student-relevant places and events, and an AI concierge that answers "what should I do next?" based on the student's profile, location, time, and budget.

**Why we'll win:**
- **Real pain, real city.** Built for actual Iași Erasmus + first-year UAIC students. Judges live here — they'll feel the authenticity.
- **AI is core, not bolted on.** The concierge isn't a chatbot widget — it's the navigation layer. This earns the 25% AI sub-score *and* the originality points.
- **Working, not mocked.** Three end-to-end flows fully functional > ten half-flows.
- **Business story is real.** ~30K Erasmus students in Romania annually + ~500K Romanian students relocating yearly = clear TAM and B2B angle to universities.

**Non-goals (cut from scope):**
- Auth / user accounts (use session-only personas for demo)
- Real crowdsourcing (seed hand-curated tips; pitch crowdsourcing as roadmap)
- Multi-city support (Iași only, but architected so it's not hardcoded)
- Native mobile app (web-first, mobile-responsive)

---

## 2. The Product

### Core concept
A new student lands in Iași. They open Student Compass, pick or build their profile (origin, status, university, language). They immediately see:
1. **What to do this week** — a personalized checklist (residence permit, RATP card, BCR account, doctor registration, UAIC orientation).
2. **What's around me** — a map with student-curated POIs (libraries, cheap food, study cafés, gyms, theaters, Filarmonica, parks).
3. **A concierge** — ask in natural language: *"I have 2 hours, I'm broke, what should I do?"* → 3 personalized recommendations with reasoning, pinned on the map.

### Killer demo flow (90 seconds)
1. **Profile**: Pre-built "Marco, Erasmus from Bologna, just arrived at UAIC FII" persona.
2. **Checklist appears** — top 5 tasks ranked by urgency. Click "Register at Inspectoratul de Imigrări" → see address, hours, required documents, Romanian phrases, walking directions.
3. **Open map** — toggle categories (study / food / culture / sport / bureaucracy) around Copou campus.
4. **Ask concierge**: *"I'm tired, have 3 hours, want to do something cultural but cheap."* → AI returns 3 picks (e.g., Palas park walk, free exhibit at Muzeul Unirii, evening concert at Casa Filarmonicii) with one-sentence reasoning each. Pins highlight on map.
5. **Switch persona**: "Ana, first-year from Botoșani" — checklist instantly changes (no visa items, more campus + social focus). Proves personalization is real.

### Unique Selling Proposition (USP)
> **The first AI arrival companion that turns a new city into a personalized week-one plan — not a generic todo list.**

Competitors are either bureaucratic (gov sites), static (Lonely Planet, university PDF guides), or generic (Google Maps, Yelp). None combine **personalization + local truth + bureaucracy assistance + discovery** in one place.

---

## 3. Team Roles (5 people)

Naming the roles matters. Owner = single point of accountability. No "we'll figure it out."

| Role | Owner | Responsibility |
|------|-------|----------------|
| **Backend Lead (B1)** | TBD | FastAPI scaffold, data model, /places, /checklist endpoints, deployment. |
| **AI Lead (B2)** | TBD | Anthropic client, prompt templates, /chat and /recommend endpoints, context injection. |
| **Data + Integration (D)** | TBD | OSM ingestion for Iași, seed all Iași-specific data (POIs, procedures, tips, personas), API testing, glue work. |
| **Frontend (F)** | TBD | Streamlit UI: profile picker, map with `streamlit-folium`, checklist screen, chat sidebar, styling. |
| **Business + Pitch (P)** | TBD | **Full-time on the 40% category.** Market analysis, business model, financials, SWOT, slide deck, demo script, pitch rehearsal. *This is the most important role.* |

**Critical:** P is not a "spare" role. The brief weights business + pitch at 70% of total score combined. Whoever is least confident coding should take this — they will arguably contribute more to victory than any single backend dev.

---

## 4. Tech Stack & Architecture

Optimized for: Python-heavy team, no experience, 24 hours, must actually work.

### Stack
- **Backend:** FastAPI + Uvicorn
- **Database:** SQLite + SQLAlchemy (one file, zero config)
- **AI:** Anthropic Claude API (`claude-haiku-4-5` for speed/cost; `claude-sonnet-4-6` for the concierge if budget allows)
- **Map data:** OpenStreetMap Overpass API (cached to SQLite at startup — do NOT hit live during demo)
- **Frontend:** Streamlit + `streamlit-folium` (pure Python, fastest path)
- **Deployment:** Render or Railway (one-command from GitHub)
- **Version control:** GitHub, branches: `main` (deploys), `dev`, `feature/<name>`

### Architecture (intentionally boring)

```
┌──────────────────┐         ┌──────────────────┐
│  Streamlit UI    │ ──HTTP→ │  FastAPI         │
│  (folium map,    │ ←JSON─  │  /places         │
│   chat sidebar,  │         │  /checklist      │
│   checklist)     │         │  /procedure/{id} │
└──────────────────┘         │  /recommend  ────┼──→ Anthropic API
                             │  /chat       ────┼──→ Anthropic API
                             └────────┬─────────┘
                                      │
                                      ▼
                             ┌──────────────────┐
                             │  SQLite          │
                             │  • places (POIs) │
                             │  • procedures    │
                             │  • personas      │
                             │  • tips          │
                             └──────────────────┘
                                      ▲
                                      │ (startup ingestion)
                             ┌──────────────────┐
                             │  OSM Overpass    │
                             │  Iași bbox       │
                             └──────────────────┘
```

### Data model (lean)

```python
Place(id, name, lat, lon, category, tags, description, source)
Procedure(id, slug, title, applies_to, steps_json, address, phrases_ro)
Persona(id, name, origin, status, university, language, profile_json)
Tip(id, category, content, location_ref, verified)
ChatSession(id, persona_id, messages_json, created_at)
```

### Endpoints (REST)
- `GET /places?lat&lon&radius&category` → list of POIs
- `GET /checklist?persona_id` → ordered list of arrival tasks
- `GET /procedure/{slug}` → step-by-step bureaucracy guide
- `POST /recommend` body `{persona_id, query, context}` → 3 recommendations with rationale
- `POST /chat` body `{persona_id, message, history}` → conversational reply
- `GET /personas` → all demo personas
- `GET /healthz` → for deploy monitor

Auto-generated Swagger docs at `/docs` — judges will see them.

---

## 5. 24-Hour Schedule

Times assume start = T+0. Adjust for breaks, but **do not skip the demo-prep blocks at the end.**

### Hour 0–2 — Kickoff & Setup (all 5)
- Read brief together (15 min). Lock scope. Agree on "won't do" list.
- Roles assigned. Demo script v1 sketched on paper.
- GitHub repo created, README skeleton, `.gitignore`, branch protection.
- Everyone has Python 3.11+, dependencies installed, can `uvicorn` and `streamlit run`.
- Anthropic API key in `.env`, in GitHub Secrets.
- Slack/Discord/WhatsApp channel for the 24h. Pinned: demo script + deploy URL.

### Hour 2–6 — Foundation (parallel)
- **B1:** FastAPI skeleton, SQLite + SQLAlchemy models, `/places` returning OSM-cached data, deploy "hello world" to Render.
- **B2:** Anthropic client wrapper, prompt template library (system prompts for concierge, checklist generator, procedure explainer), `/chat` echo endpoint.
- **F:** Streamlit skeleton with sidebar (persona picker), main panel with folium map of Iași centered on Copou, category filter checkboxes (placeholder data).
- **D:** Write OSM Overpass query for Iași, run it, dump to SQLite. Start drafting 5 personas + 30 POIs + 5 bureaucracy procedures + 20 tips (in a `seed.py`).
- **P:** Market research: Erasmus to Romania stats, UAIC international student numbers, competitor scan (Erasmus+ app, Welcome.eu, Workwide, Housing Anywhere, university orientation guides). Start a `BUSINESS.md`.

**Checkpoint at H6:** map renders with real Iași POIs from SQLite. Profile picker works. Deploy is live. P has competitor table + market sizing draft.

### Hour 6–10 — Core features
- **B1:** `/checklist` endpoint that returns persona-specific tasks. `/procedure/{slug}` returns step-by-step.
- **B2:** `/recommend` endpoint with real Claude call: takes persona + query + nearby places, returns 3 picks + rationale. Tune the prompt.
- **F:** Checklist view, procedure detail view, chat box that hits `/chat`.
- **D:** Finalize seed data (this is the demo content — quality matters). Write all 5 bureaucracy procedures fully (residence permit, NIN, BCR account, RATP transport card, family doctor).
- **P:** Cost structure, revenue model (B2C freemium + B2B universities), draft slide outline.

**Checkpoint at H10:** end-to-end flow works for one persona. Map + checklist + concierge all hit real backend.

### Hour 10–14 — Differentiation
- **B1:** Add "context" to concierge: time of day, weather (optional, OpenWeather free tier), what the user has already done from checklist.
- **B2:** Streaming responses for concierge (uses Anthropic SSE) — looks impressive in demo. Cache common queries.
- **F:** Style pass: pick a 3-color palette (use Coolors), consistent fonts, loading spinners, clear empty states. Make it look intentional, not "Streamlit default."
- **D:** Romanian language quick-help: 10 phrases per situation (pharmacy, asking directions, registering at police), embedded in procedure pages.
- **P:** Financial projections: break-even calc, MRR targets, 3-year forecast. Start drafting slide deck in Slides/PowerPoint.

**Checkpoint at H14:** all 5 personas demo-able. Concierge streaming. Looks polished. Business doc 70% done.

### Hour 14–18 — Hardening + Polish
- **B1 + B2:** Bug bash. Error handling on all endpoints (no 500s in front of judges). Rate limit fallbacks for Claude.
- **F:** Mobile-responsive check (Streamlit handles most). Add app icon, header, footer with team name + GitHub link.
- **D:** Final demo data pass: pick the EXACT examples the demo will use, make sure they look great. Add at least one timely event (e.g., real upcoming concert at Filarmonica Iași) to feel alive.
- **P:** Slide deck full draft. SWOT analysis. USP one-liner finalized.

**Checkpoint at H18:** "Demo freeze" — no more new features. Anything not built is roadmap.

### Hour 18–22 — Demo + Pitch Prep
- **All:** Deploy final to production URL. Smoke test on judge-style devices (laptop + phone).
- **F + D:** Record a 60-second backup demo video (in case venue wifi dies).
- **P + 1 dev:** Practice pitch 3 full times with team timer. Iterate on slides after each. Prepare Q&A answers for the obvious questions (see Section 8).
- **B1 + B2:** Write README.md (project overview, architecture diagram, how to run, screenshots).

### Hour 22–24 — Buffer + Sleep
- Final demo rehearsal.
- Push final code, tag release.
- Sleep at least 1 hour if possible — alert presenters score better.
- Pick your two strongest speakers for pitch + demo (one talks, one drives the screen).

---

## 6. Business Viability Workstream (40% — OWN THIS)

This is the largest scoring category and most teams under-invest in it. P should be working on this from Hour 2.

### Deliverable: `BUSINESS.md` with these sections

**Problem (with numbers)**
- ~30,000 Erasmus students arrive in Romania each year (source: ANPCDEFP / ec.europa.eu — P to verify).
- ~500,000 Romanian students relocate within the country for university each year.
- Average 2–3 weeks of "settling friction" per student. Common drop-out reason in first semester for international students = bureaucratic exhaustion.

**Target market (segmented)**
- **Tier 1 (highest pain, willing to pay):** Erasmus + degree-seeking international students. ~50K active in Romania at any time.
- **Tier 2:** Romanian first-year students moving to new city. ~150K/year.
- **Tier 3:** Professional newcomers (interns, summer schools). Smaller but high LTV.

**Competitors**
| Competitor | What they do | Why we win |
|------------|--------------|------------|
| Erasmus+ app (official) | Static info, EU-wide | Generic, no AI, no city-specific guide |
| Welcome.eu / HousingAnywhere | Housing only | Doesn't touch bureaucracy or daily life |
| Google Maps / Yelp | POI discovery | No student context, no personalization, no procedures |
| University intranet | Official info | Siloed, dry, no AI, often outdated |
| Lonely Planet / city blogs | Static city tips | Not personalized, not actionable, not bureaucratic |

**Unique Selling Proposition**
> The only product that personalizes the entire first month — bureaucracy, daily life, and discovery — using AI tuned to a student's profile and current location.

**Revenue model**
- **B2C Freemium:** Free tier (basic checklist + map). Premium €2.99/mo (unlimited AI concierge, offline mode, saved itineraries).
- **B2B Institutional:** €2–5 per student/year licensed to universities and Erasmus offices. White-labeled version for international student services.
- **Local partnerships:** Sponsored listings from student-aligned businesses (cafés, gyms, mobile carriers) — strictly opt-in and labeled.

**Unit economics (illustrative — verify before final pitch)**
- AI cost per active user/month: ~€0.05 (Claude Haiku, ~50 queries)
- Infra cost per user/month: ~€0.02 at scale
- Customer acquisition cost (university channel): ~€0.50/student
- LTV (B2C premium): ~€18 over 6 months avg
- LTV (B2B): ~€15 over 5-year contract avg

**Break-even**
- Fixed monthly costs at launch: ~€800 (hosting + APIs + minimal team)
- Break-even at ~270 premium subscribers OR 3 university contracts (~3,000 students licensed)
- Target: break-even in month 6 post-launch.

**Growth strategy / roadmap**
- **Q1:** Iași MVP launch (UAIC + alumni network seed)
- **Q2:** Cluj, Bucharest, Timișoara (top Romanian university cities)
- **Q3:** Erasmus+ partnership pilot, expand to other CEE Erasmus destinations (Prague, Krakow, Budapest)
- **Q4:** Mentorship layer (peer matching), monetize community

**SWOT**
- **Strengths:** First mover in AI-personalized arrival, deep local data, low cost to run.
- **Weaknesses:** Cold-start data problem outside Iași, depends on third-party LLM pricing.
- **Opportunities:** Erasmus+ growing 8% YoY post-COVID, universities desperate for retention tools, AI now cheap enough.
- **Threats:** Universities build in-house, Google adds AI to Maps, Erasmus+ official app gets smart.

---

## 7. Pitch Plan (30%)

### Format
- 7 minutes pitch + 3 minutes Q&A
- Two presenters: one talks (storyteller), one drives the screen + demo
- Slide deck: max 12 slides, low text, big visuals

### Slide structure (7 min)

| # | Slide | Time | Content |
|---|-------|------|---------|
| 1 | Title | 10s | Student Compass + team + tagline |
| 2 | Hook (story) | 50s | "Marco from Bologna, day 14 in Iași, still hasn't registered..." |
| 3 | Problem | 45s | Stats: 30K Erasmus + 500K relocating; 2–3 weeks of friction |
| 4 | Solution | 45s | One screenshot, three pillars: Checklist, Map, Concierge |
| 5–8 | **LIVE DEMO** | 2m | The 90s flow + 30s buffer |
| 9 | Tech | 45s | Architecture diagram, AI integration, Iași-specific data |
| 10 | Business | 1m | Market, USP, revenue, break-even |
| 11 | Roadmap | 30s | Iași → Romania → Europe |
| 12 | Ask + Close | 15s | "Help us help every newcomer feel at home." |

### Q&A preparation — drill these answers
- *"How is this different from Google Maps?"* → Personalization + bureaucracy + student context. Maps gives you a pin; we give you a plan.
- *"Why would a university pay for this?"* → International student retention is a board-level metric. Drop-outs cost €€€. We reduce week-one churn.
- *"How do you handle wrong AI answers about bureaucracy?"* → Procedures are human-curated and structured. The AI summarizes our data, doesn't hallucinate it. RAG-style architecture.
- *"What's the moat?"* → Data: hand-verified procedures and seeded tips per city are hard to replicate fast.
- *"Why now?"* → LLM cost is now <€0.05/user/mo. Wasn't viable 18 months ago.
- *"How big can this get?"* → 4.4M Erasmus students 1987–2023. ~1.3M/yr now. CEE market alone ~250K/yr.

---

## 8. Demo Script (90 seconds)

Memorize this. Practice it 5 times.

```
[0:00] "This is Marco. He just landed in Iași from Bologna for his Erasmus at UAIC.
        Day 1, he opens Student Compass."
        → [Select Marco persona]

[0:10] "Immediately, he sees the five most urgent things he needs to do this week."
        → [Point at checklist: residence permit, RATP card, BCR account, family doctor, UAIC orientation]

[0:20] "He clicks the residence permit task..."
        → [Click task]
        "...and gets the exact address, opening hours, required documents, plus
         Romanian phrases he'll need at the counter."

[0:35] "Now he wants to explore. He opens the map."
        → [Switch to map, filter to "Study spots"]
        "Libraries, student cafés, study spaces — everything filtered for a student."

[0:50] "But here's where it gets interesting. He asks the concierge:
        'I have three hours, I'm tired, I want something cultural but cheap.'"
        → [Type in chat, hit send]
        → [AI streams response with 3 picks + pins on map]

[1:15] "Three personalized suggestions, with reasoning, pinned on the map.
        And because we know Marco's profile, those picks are different from..."
        → [Switch to Ana persona]
        "...Ana, a first-year from Botoșani. Her checklist is completely different —
         no visa items, more campus-focused."

[1:30] "One student. One city. One compass."
```

---

## 9. Risk Register & Mitigations

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Mockup penalty (judges spot hardcoded data) | Med | High | Real OSM data, real Claude calls, real DB. No `if persona == "Marco": return [...]`. |
| AI fails mid-demo | Med | High | Cache Marco's exact demo responses. Fallback to cached on timeout. Have offline-mode toggle. |
| Wifi dies at venue | Low | Critical | Record 60s screen-capture demo as backup. Bring mobile hotspot. |
| Scope creep | High | High | Hour-18 demo freeze is sacred. Anything new = roadmap slide. |
| Team burnout / fights | Med | Med | Rotate sleep, eat properly, P keeps morale up. No blame culture — fix-forward only. |
| Streamlit looks unprofessional | Med | Med | Custom CSS, color palette, hide "Made with Streamlit" footer. Practice the demo so the UI is in motion. |
| Romanian-language details wrong | Low | High | Have a native Romanian speaker on the team review procedure text + phrases. |
| Pitch runs over 7 min | High | Med | Strict 90s demo. Slide #5–8 timer on stage. Cut on-the-fly if needed. |

---

## 10. Definition of Done (per feature)

Before marking a feature complete:
- [ ] Endpoint returns real data (not stubbed)
- [ ] Frontend shows the data without errors
- [ ] Works for at least 2 different personas
- [ ] No console errors / no FastAPI 500s
- [ ] Pushed to `dev`, then merged to `main`, deployed
- [ ] Tested on deployed URL, not just locally
- [ ] Demo script step that uses this feature still works end-to-end

**Pro tip:** A few polished, complete flows always beat many half-built ones. The brief literally says this twice.

---

## Appendix A — Starter code references

```python
# OSM Overpass query for Iași student-relevant POIs
QUERY = """
[out:json][timeout:25];
(
  // Bounding box for Iași
  node["amenity"~"library|cafe|theatre|university|bank|pharmacy|hospital|police"]
       (47.10,27.50,47.22,27.68);
  node["leisure"~"fitness_centre|park|sports_centre"]
       (47.10,27.50,47.22,27.68);
  node["tourism"~"museum|gallery|attraction"]
       (47.10,27.50,47.22,27.68);
);
out body;
"""
```

```python
# Concierge system prompt skeleton
SYSTEM = """You are Student Compass, a local guide for students newly arrived in Iași, Romania.
You speak warmly and practically. You NEVER invent places — you only recommend from the list of
nearby places provided in the user message.

The student's profile:
- Name: {name}
- Origin: {origin}
- Status: {status}
- Language: {language}
- University: {university}

Tailor recommendations to their budget, mood, and time available. Return EXACTLY 3 picks as JSON:
[{{"name": "...", "reason": "<one sentence>", "place_id": "..."}}, ...]
"""
```

---

## Appendix B — Critical "won't do" list

These were considered and explicitly cut. Pitch them as roadmap, not as gaps.
- User accounts / login
- Real-time crowdsourcing
- Native mobile app
- Multi-city support (architected for it, demo Iași only)
- Payment integration
- Social/peer matching
- Real-time transport routing
- Offline mode

---

*End of plan. Now go build. Update the demo script the moment scope changes.*
